print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
print("Complementario2: 10 primeros pares y cubos")
print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")

start = 2
stop = 20
step = 2 
for i in range(start, stop+1, step):
    c = i**3
    
print("El cubo de ", i, "es ", c)